function CodeMetrics() {
	 this.metricsArray = {};
	 this.metricsArray.var = new Array();
	 this.metricsArray.fcn = new Array();
	 this.metricsArray.var["Image0.c:rtM_"] = {file: "C:\\Users\\s2130866\\MATLAB\\Projects\\parrotMinidroneCompetition_allscaled\\work\\Image0_ert_rtw\\Image0.c",
	size: 4};
	 this.metricsArray.var["rtDW"] = {file: "C:\\Users\\s2130866\\MATLAB\\Projects\\parrotMinidroneCompetition_allscaled\\work\\Image0_ert_rtw\\Image0.c",
	size: 246736};
	 this.metricsArray.var["rtInf"] = {file: "C:\\Users\\s2130866\\MATLAB\\Projects\\parrotMinidroneCompetition_allscaled\\work\\Image0_ert_rtw\\Image0.c",
	size: 8};
	 this.metricsArray.var["rtInfF"] = {file: "C:\\Users\\s2130866\\MATLAB\\Projects\\parrotMinidroneCompetition_allscaled\\work\\Image0_ert_rtw\\Image0.c",
	size: 4};
	 this.metricsArray.var["rtMinusInf"] = {file: "C:\\Users\\s2130866\\MATLAB\\Projects\\parrotMinidroneCompetition_allscaled\\work\\Image0_ert_rtw\\Image0.c",
	size: 8};
	 this.metricsArray.var["rtMinusInfF"] = {file: "C:\\Users\\s2130866\\MATLAB\\Projects\\parrotMinidroneCompetition_allscaled\\work\\Image0_ert_rtw\\Image0.c",
	size: 4};
	 this.metricsArray.var["rtNaN"] = {file: "C:\\Users\\s2130866\\MATLAB\\Projects\\parrotMinidroneCompetition_allscaled\\work\\Image0_ert_rtw\\Image0.c",
	size: 8};
	 this.metricsArray.var["rtNaNF"] = {file: "C:\\Users\\s2130866\\MATLAB\\Projects\\parrotMinidroneCompetition_allscaled\\work\\Image0_ert_rtw\\Image0.c",
	size: 4};
	 this.metricsArray.var["rtY"] = {file: "C:\\Users\\s2130866\\MATLAB\\Projects\\parrotMinidroneCompetition_allscaled\\work\\Image0_ert_rtw\\Image0.c",
	size: 48};
	 this.metricsArray.fcn["Image0.c:SystemCore_step"] = {file: "C:\\Users\\s2130866\\MATLAB\\Projects\\parrotMinidroneCompetition_allscaled\\work\\Image0_ert_rtw\\Image0.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Image0.c:mod"] = {file: "C:\\Users\\s2130866\\MATLAB\\Projects\\parrotMinidroneCompetition_allscaled\\work\\Image0_ert_rtw\\Image0.c",
	stack: 17,
	stackTotal: 17};
	 this.metricsArray.fcn["Image0.c:rtGetInf"] = {file: "C:\\Users\\s2130866\\MATLAB\\Projects\\parrotMinidroneCompetition_allscaled\\work\\Image0_ert_rtw\\Image0.c",
	stack: 20,
	stackTotal: 20};
	 this.metricsArray.fcn["Image0.c:rtGetInfF"] = {file: "C:\\Users\\s2130866\\MATLAB\\Projects\\parrotMinidroneCompetition_allscaled\\work\\Image0_ert_rtw\\Image0.c",
	stack: 4,
	stackTotal: 4};
	 this.metricsArray.fcn["Image0.c:rtGetMinusInf"] = {file: "C:\\Users\\s2130866\\MATLAB\\Projects\\parrotMinidroneCompetition_allscaled\\work\\Image0_ert_rtw\\Image0.c",
	stack: 20,
	stackTotal: 20};
	 this.metricsArray.fcn["Image0.c:rtGetMinusInfF"] = {file: "C:\\Users\\s2130866\\MATLAB\\Projects\\parrotMinidroneCompetition_allscaled\\work\\Image0_ert_rtw\\Image0.c",
	stack: 4,
	stackTotal: 4};
	 this.metricsArray.fcn["Image0.c:rtGetNaN"] = {file: "C:\\Users\\s2130866\\MATLAB\\Projects\\parrotMinidroneCompetition_allscaled\\work\\Image0_ert_rtw\\Image0.c",
	stack: 20,
	stackTotal: 20};
	 this.metricsArray.fcn["Image0.c:rtGetNaNF"] = {file: "C:\\Users\\s2130866\\MATLAB\\Projects\\parrotMinidroneCompetition_allscaled\\work\\Image0_ert_rtw\\Image0.c",
	stack: 4,
	stackTotal: 4};
	 this.metricsArray.fcn["Image0.c:rtIsInf"] = {file: "C:\\Users\\s2130866\\MATLAB\\Projects\\parrotMinidroneCompetition_allscaled\\work\\Image0_ert_rtw\\Image0.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Image0.c:rtIsInfF"] = {file: "C:\\Users\\s2130866\\MATLAB\\Projects\\parrotMinidroneCompetition_allscaled\\work\\Image0_ert_rtw\\Image0.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Image0.c:rtIsNaN"] = {file: "C:\\Users\\s2130866\\MATLAB\\Projects\\parrotMinidroneCompetition_allscaled\\work\\Image0_ert_rtw\\Image0.c",
	stack: 13,
	stackTotal: 13};
	 this.metricsArray.fcn["Image0.c:rtIsNaNF"] = {file: "C:\\Users\\s2130866\\MATLAB\\Projects\\parrotMinidroneCompetition_allscaled\\work\\Image0_ert_rtw\\Image0.c",
	stack: 4,
	stackTotal: 4};
	 this.metricsArray.fcn["Image0.c:rt_InitInfAndNaN"] = {file: "C:\\Users\\s2130866\\MATLAB\\Projects\\parrotMinidroneCompetition_allscaled\\work\\Image0_ert_rtw\\Image0.c",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["Image0_initialize"] = {file: "C:\\Users\\s2130866\\MATLAB\\Projects\\parrotMinidroneCompetition_allscaled\\work\\Image0_ert_rtw\\Image0.c",
	stack: 24,
	stackTotal: 24};
	 this.metricsArray.fcn["Image0_step"] = {file: "C:\\Users\\s2130866\\MATLAB\\Projects\\parrotMinidroneCompetition_allscaled\\work\\Image0_ert_rtw\\Image0.c",
	stack: 51,
	stackTotal: 51};
	 this.metricsArray.fcn["MW_Build_RGB"] = {file: "C:\\ProgramData\\MATLAB\\SupportPackages\\R2021a\\toolbox\\target\\supportpackages\\parrot\\src\\rsedu_image.c",
	stack: 36,
	stackTotal: 36};
	 this.metricsArray.fcn["MW_Build_YUV"] = {file: "C:\\ProgramData\\MATLAB\\SupportPackages\\R2021a\\toolbox\\target\\supportpackages\\parrot\\src\\rsedu_image.c",
	stack: 24,
	stackTotal: 24};
	 this.metricsArray.fcn["RSEDU_optical_flow"] = {file: "C:\\ProgramData\\MATLAB\\SupportPackages\\R2021a\\toolbox\\target\\supportpackages\\parrot\\src\\rsedu_of.c",
	stack: 4,
	stackTotal: 4};
	 this.metricsArray.fcn["__errno_location"] = {file: "C:\\Program Files\\MATLAB\\R2021a\\polyspace\\verifier\\cxx\\include\\include-libc\\bits\\errno.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["access"] = {file: "C:\\Program Files\\MATLAB\\R2021a\\polyspace\\verifier\\cxx\\include\\include-libc\\unistd.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["atan2"] = {file: "C:\\Program Files\\MATLAB\\R2021a\\polyspace\\verifier\\cxx\\include\\include-libc\\bits\\mathcalls.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["byteswap.h:__bswap_32"] = {file: "C:\\Program Files\\MATLAB\\R2021a\\polyspace\\verifier\\cxx\\include\\include-libc\\bits\\byteswap.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["byteswap.h:__bswap_64"] = {file: "C:\\Program Files\\MATLAB\\R2021a\\polyspace\\verifier\\cxx\\include\\include-libc\\bits\\byteswap.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["ceil"] = {file: "C:\\Program Files\\MATLAB\\R2021a\\polyspace\\verifier\\cxx\\include\\include-libc\\bits\\mathcalls.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["close"] = {file: "C:\\Program Files\\MATLAB\\R2021a\\polyspace\\verifier\\cxx\\include\\include-libc\\unistd.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["fabs"] = {file: "C:\\Program Files\\MATLAB\\R2021a\\polyspace\\verifier\\cxx\\include\\include-libc\\bits\\mathcalls.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["fclose"] = {file: "C:\\Program Files\\MATLAB\\R2021a\\polyspace\\verifier\\cxx\\include\\include-libc\\stdio.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["floor"] = {file: "C:\\Program Files\\MATLAB\\R2021a\\polyspace\\verifier\\cxx\\include\\include-libc\\bits\\mathcalls.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["fmod"] = {file: "C:\\Program Files\\MATLAB\\R2021a\\polyspace\\verifier\\cxx\\include\\include-libc\\bits\\mathcalls.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["fopen"] = {file: "C:\\Program Files\\MATLAB\\R2021a\\polyspace\\verifier\\cxx\\include\\include-libc\\stdio.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["fprintf"] = {file: "C:\\Program Files\\MATLAB\\R2021a\\polyspace\\verifier\\cxx\\include\\include-libc\\stdio.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["free"] = {file: "C:\\Program Files\\MATLAB\\R2021a\\polyspace\\verifier\\cxx\\include\\include-libc\\stdlib.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["gettimeofday"] = {file: "C:\\Program Files\\MATLAB\\R2021a\\polyspace\\verifier\\cxx\\include\\include-libc\\sys\\time.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["malloc"] = {file: "C:\\Program Files\\MATLAB\\R2021a\\polyspace\\verifier\\cxx\\include\\include-libc\\stdlib.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["memcpy"] = {file: "C:\\Program Files\\MATLAB\\R2021a\\polyspace\\verifier\\cxx\\include\\include-libc\\string.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["memset"] = {file: "C:\\Program Files\\MATLAB\\R2021a\\polyspace\\verifier\\cxx\\include\\include-libc\\string.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["mkdir"] = {file: "C:\\Program Files\\MATLAB\\R2021a\\polyspace\\verifier\\cxx\\include\\include-libc\\sys\\stat.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["open"] = {file: "C:\\Program Files\\MATLAB\\R2021a\\polyspace\\verifier\\cxx\\include\\include-libc\\fcntl.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["printf"] = {file: "C:\\Program Files\\MATLAB\\R2021a\\polyspace\\verifier\\cxx\\include\\include-libc\\stdio.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["ptimer_init"] = {file: "C:\\ProgramData\\MATLAB\\SupportPackages\\R2021a\\toolbox\\target\\supportpackages\\parrot\\src\\ptimer.c",
	stack: 4,
	stackTotal: 4};
	 this.metricsArray.fcn["ptimer_start"] = {file: "C:\\ProgramData\\MATLAB\\SupportPackages\\R2021a\\toolbox\\target\\supportpackages\\parrot\\src\\ptimer.c",
	stack: 8,
	stackTotal: 8};
	 this.metricsArray.fcn["ptimer_stopstore"] = {file: "C:\\ProgramData\\MATLAB\\SupportPackages\\R2021a\\toolbox\\target\\supportpackages\\parrot\\src\\ptimer.c",
	stack: 24,
	stackTotal: 24};
	 this.metricsArray.fcn["rt_atan2d_snf"] = {file: "C:\\Users\\s2130866\\MATLAB\\Projects\\parrotMinidroneCompetition_allscaled\\work\\Image0_ert_rtw\\Image0.c",
	stack: 16,
	stackTotal: 16};
	 this.metricsArray.fcn["rt_roundd_snf"] = {file: "C:\\Users\\s2130866\\MATLAB\\Projects\\parrotMinidroneCompetition_allscaled\\work\\Image0_ert_rtw\\Image0.c",
	stack: 8,
	stackTotal: 8};
	 this.metricsArray.fcn["sprintf"] = {file: "C:\\Program Files\\MATLAB\\R2021a\\polyspace\\verifier\\cxx\\include\\include-libc\\stdio.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["sqrt"] = {file: "C:\\Program Files\\MATLAB\\R2021a\\polyspace\\verifier\\cxx\\include\\include-libc\\bits\\mathcalls.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["strerror"] = {file: "C:\\Program Files\\MATLAB\\R2021a\\polyspace\\verifier\\cxx\\include\\include-libc\\string.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["strlen"] = {file: "C:\\Program Files\\MATLAB\\R2021a\\polyspace\\verifier\\cxx\\include\\include-libc\\string.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["usleep"] = {file: "C:\\Program Files\\MATLAB\\R2021a\\polyspace\\verifier\\cxx\\include\\include-libc\\unistd.h",
	stack: 0,
	stackTotal: 0};
	 this.metricsArray.fcn["write"] = {file: "C:\\Program Files\\MATLAB\\R2021a\\polyspace\\verifier\\cxx\\include\\include-libc\\unistd.h",
	stack: 0,
	stackTotal: 0};
	 this.getMetrics = function(token) { 
		 var data;
		 data = this.metricsArray.var[token];
		 if (!data) {
			 data = this.metricsArray.fcn[token];
			 if (data) data.type = "fcn";
		 } else { 
			 data.type = "var";
		 }
	 return data; }; 
	 this.codeMetricsSummary = '<a href="Image0_metrics.html">Global Memory: 246824(bytes) Maximum Stack: 51(bytes)</a>';
	}
CodeMetrics.instance = new CodeMetrics();
